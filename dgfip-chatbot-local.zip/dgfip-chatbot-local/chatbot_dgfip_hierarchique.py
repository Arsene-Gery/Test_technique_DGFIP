import pandas as pd
import numpy as np
import re
from collections import defaultdict
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# === Nettoyage ===
def nettoyer_et_tronquer(texte, limite=1000):
    return texte.strip().replace('\n', ' ')[:limite]

def normaliser_texte(texte):
    texte = texte.lower()
    texte = re.sub(r"[^a-zàâçéèêëîïôûùüÿñæœ\s-]", "", texte)
    return texte

# === Chargement des données ===
df_fiches = pd.read_csv("info_particulier_impot.csv")
df_fiches["Texte_Concat"] = (
    df_fiches["Titre"].fillna("") + " : " + df_fiches["Texte"].fillna("")
).apply(lambda x: nettoyer_et_tronquer(x))

# Indexation thématique
df_fiches["Theme"] = df_fiches["Titre"].fillna("").apply(normaliser_texte)
index_theme = defaultdict(set)
for idx, theme in enumerate(df_fiches["Theme"]):
    for mot in theme.split():
        index_theme[mot].add(idx)

# === Chargement du modèle ===
print("🔄 Chargement du modèle SBERT...")
modele = SentenceTransformer("dangvantuan/sentence-camembert-large")
fiches_textes = df_fiches["Texte_Concat"].tolist()
fiches_embeddings = modele.encode(fiches_textes, convert_to_tensor=True).cpu().numpy()

# === Moteur de recherche ===
def chercher_fiche(question, seuil_min=3):
    mots_question = set(normaliser_texte(question).split())
    indices_possibles = set()
    for mot in mots_question:
        indices_possibles.update(index_theme.get(mot, []))
    if len(indices_possibles) < seuil_min:
        indices_possibles = set(range(len(fiches_textes)))

    sous_ensemble = [fiches_embeddings[i] for i in indices_possibles]
    question_embedding = modele.encode(question, convert_to_tensor=True).cpu().numpy().reshape(1, -1)
    similarites = cosine_similarity(question_embedding, sous_ensemble).flatten()

    index_local_max = np.argmax(similarites)
    index_global_max = list(indices_possibles)[index_local_max]

    return {
        "question": question,
        "titre": df_fiches["Titre"].iloc[index_global_max],
        "url": df_fiches["URL"].iloc[index_global_max],
        "similarité": float(similarites[index_local_max]),
        "nb_fiches_consultées": len(indices_possibles)
    }

# === Interface console ===
if __name__ == "__main__":
    print("\n💬 Chatbot DGFiP (version locale)")
    while True:
        q = input("\nPosez votre question (ou 'exit') :\n> ")
        if q.lower() == "exit":
            break
        rep = chercher_fiche(q)
        print(f"\n📌 Fiche : {rep['titre']}")
        print(f"🔗 URL  : {rep['url']}")
        print(f"📊 Score : {rep['similarité']:.4f} sur {rep['nb_fiches_consultées']} fiches analysées")
